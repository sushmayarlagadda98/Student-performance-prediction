getwd()
setwd("C:/Users/my laptop/Documents")
sd<-read.csv("lg.csv")
library(e1071)
std=sort(sample(nrow(sd),nrow(sd)*.7))
traindb<-sd[std,]
testdb<-sd[std,]
NB<-naiveBayes(Type~.,data=traindb)
print(NB)
predNB<-predict(NB,testdb)
table(testdb$Type,predNB)
plot(predNB)

